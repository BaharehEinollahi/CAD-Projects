#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstring>
#include <algorithm>

using namespace std;

const string NAMED_PIPE = "np";

vector<vector<string>> parse_commands(const string& line);
int execute_command(const vector<string>& args);
int execute_pipeline(const vector<vector<string>>& command_groups, int& namedPipe_fd);
int handle_redirection(vector<string>& current_group, int& input_fd, int& output_fd, bool& redirect_out);

void builtin_echo(const vector<string>& args);
void builtin_print_n(const vector<string>& args);
void builtin_len(const vector<string>& args);
string unbuffered_getline(int fd);

int main() {
    unlink(NAMED_PIPE.c_str());
    if (mkfifo(NAMED_PIPE.c_str(), 0666) == -1 && errno != EEXIST) {
        perror("mkfifo failed");
        return 1;
    }

    int namedPipe_fd = open(NAMED_PIPE.c_str(), O_RDWR);
    if (namedPipe_fd == -1) {
        perror("Failed to open keepalive pipe");
        return 1;
    }
    string line;
    cout << "ray > ";
    while (getline(cin, line) && line != "exit") {
        if (line.empty()) {
            cout << "ray > ";
            continue;
        }
        auto command_groups = parse_commands(line);
        if (!command_groups.empty()) {
            execute_pipeline(command_groups, namedPipe_fd);
        }
        cout << "ray > ";
    }

    close(namedPipe_fd);
    unlink(NAMED_PIPE.c_str());
    cout << "Exiting ray." << endl;
    return 0;
}

int execute_pipeline(const vector<vector<string>>& command_groups, int& namedPipe_fd) {
    int input_fd = STDIN_FILENO;
    int num_commands = command_groups.size();
    vector<pid_t> pids;
    
    for (int i = 0; i < num_commands; ++i) {
        vector<string> current_group = command_groups[i];
        int output_fd = STDOUT_FILENO;
        int pipe_fds[2];
        bool redirect_out = false;

        if (handle_redirection(current_group, input_fd, output_fd, redirect_out) != 0)  
            return 1;
        if (i < num_commands - 1 && redirect_out) {
            cerr << "Error: Cannot redirect output to named pipe in the middle of a pipeline." << endl;
            return 1;
        }

        if (i < num_commands - 1){
            pipe(pipe_fds);
            output_fd = pipe_fds[1];
        }
        pid_t pid = fork();
 
        if (pid == 0) {
            if (input_fd != STDIN_FILENO) {
                dup2(input_fd, STDIN_FILENO);
                close(input_fd);
            }
            if (output_fd != STDOUT_FILENO) {
                dup2(output_fd, STDOUT_FILENO);
                close(output_fd);
            }
            if (i < num_commands - 1 && !redirect_out)
                close(pipe_fds[0]); 
            exit(execute_command(current_group));
        } 
        else {
            pids.push_back(pid);
            if (input_fd    != STDIN_FILENO)    close(input_fd);
            if (output_fd   != STDOUT_FILENO)   close(output_fd);
            
            if (i < num_commands - 1 && !redirect_out)
                input_fd = pipe_fds[0];
             else 
                input_fd = STDIN_FILENO;
        }
    }
    for (pid_t pid : pids)  waitpid(pid, nullptr, 0);
    return 0;
}

int handle_redirection(vector<string>& current_group, int& input_fd, int& output_fd, bool& redirect_out) {
    bool redirect_in = false;

    for (size_t j = 0; j < current_group.size(); ++j) {
        if (current_group[j] == ">" && j + 1 < current_group.size() && current_group[j+1] == NAMED_PIPE) {
            output_fd = open(NAMED_PIPE.c_str(), O_WRONLY | O_APPEND);
            redirect_out = true;
        } else if (current_group[j] == "<" && j + 1 < current_group.size() && current_group[j+1] == NAMED_PIPE) {
            if (input_fd != STDIN_FILENO) {
                perror("Error input redirection conflict with pipe");
                return 1;
            }
            
            input_fd = open(NAMED_PIPE.c_str(), O_RDONLY);
            redirect_in = true;
        }
    }
    
    if (redirect_in || redirect_out) {
        auto it = remove_if(current_group.begin(), current_group.end(), [](const string& s) {
            return s == ">" || s == "<" || s == NAMED_PIPE;
        });
        current_group.erase(it, current_group.end());
    }

    if ((redirect_in && input_fd == -1) || (redirect_out && output_fd == -1)) {
        perror("Error opening named pipe");
        return 1;
    }
    if (current_group.empty()) {
        perror("No command specified after redirection");
        return 1; 
    }
    return 0;
}

int execute_command(const vector<string>& args) {
    if (args.empty()) return 0;
    const string& cmd = args[0];

    if (cmd == "echo") {
        builtin_echo(args);
    } else if (cmd == "print_n") {
        builtin_print_n(args);
    } else if (cmd == "len") {
        builtin_len(args);
    } else {
        cerr << "ray: Command not found: " << cmd << endl;
        return 127;
    }
    return 0;
}

void builtin_echo(const vector<string>& args) {
    string output_str = "";
    
    if (!isatty(STDIN_FILENO)) {
        output_str = unbuffered_getline(STDIN_FILENO);
    }
    else if (args.size() > 1) {
        for (size_t i = 1; i < args.size(); ++i) {
            output_str += args[i] + (i == args.size() - 1 ? "" : " ");
        }
    }
    cout<< output_str <<"\n";
}

void builtin_print_n(const vector<string>& args) {
    if (args.size() < 2) return;
    int count = stoi(args[1]);
    string output_str;

    for (int i = 0; i < count; ++i) {
        output_str += "hello";
        if (i < count - 1) {
            output_str += ", ";
        }
    }
    cout<< output_str<<"\n";
}

void builtin_len(const vector<string>& args) {
    string input_str;
    bool from_stdin = false;

    if (!isatty(STDIN_FILENO)) {
        input_str = unbuffered_getline(STDIN_FILENO);
    } 
    else if (!from_stdin && args.size() > 1) {
        for (size_t i = 1; i < args.size(); ++i) {
            input_str += args[i] + (i == args.size() - 1 ? "" : " ");
        }
    } else{
        getline(cin, input_str);
    }

    string length_str = to_string(input_str.length()) + "\n";
    cout<< length_str;
}

string unbuffered_getline(int fd) {
    string line;
    char c;
    while (read(fd, &c, 1) > 0) {
        if (c == '\n') break;
        line += c;
    }
    return line;
}

vector<vector<string>> parse_commands(const string& line) {
    vector<vector<string>> command_groups;
    stringstream ss(line);
    string segment;
    while (getline(ss, segment, '|')) {
        stringstream seg_ss(segment);
        string token;
        vector<string> args;
        while (seg_ss >> token) {
            args.push_back(token);
        }
        if (!args.empty()) {
            command_groups.push_back(args);
        }
    }
    return command_groups;
}